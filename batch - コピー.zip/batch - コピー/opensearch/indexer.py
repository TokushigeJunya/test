"""OpenSearch インデクサー

【役割】
- インデックスの作成（初回のみ）
- ドキュメントのbulk投入
- 動作確認用の検索
"""

from opensearchpy import OpenSearch, helpers

INDEX_NAME = "edinet-reports"

# ── インデックスのマッピング定義 ──────────────────────────────────────────────
# インデックス作成時に1回だけ使われる。
# 後から変更するにはインデックスを削除して再作成する必要がある。
MAPPINGS = {
    "mappings": {
        "properties": {
            # keyword型: 完全一致・フィルタ・集計（aggs）に使う
            #   → 形態素解析されない。"E01777" で検索したら "E01777" しかヒットしない
            "doc_id":       {"type": "keyword"},
            "edinet_code":  {"type": "keyword"},
            "form_code":    {"type": "keyword"},

            # text型(kuromoji): 全文検索に使う
            #   → 投入時・検索時に kuromoji で形態素解析される
            #   → "ソニーグループ" で検索すると "ソニーグループ株式会社" がヒットする
            #   → fields.keyword: 集計（aggs）用の完全一致サブフィールド
            #     ※ 明示的マッピングでは .keyword は自動生成されないため明示が必要
            "company_name": {
                "type":     "text",
                "analyzer": "kuromoji",
                "fields": {
                    "keyword": {"type": "keyword"}   # company_name.keyword で集計できる
                }
            },

            # keyword型: "有価証券報告書－第107期..." をそのまま保存・表示するだけなので keyword
            "form_name":    {"type": "keyword"},

            # date型: 期間フィルタや時系列グラフに使う
            #   → "2024-06-25" のような文字列が日付として解釈される
            "period_start": {"type": "date"},
            "period_end":   {"type": "date"},
            "submitted_at": {"type": "date"},

            # text型(kuromoji): 本文の全文検索用。最も重要なフィールド
            #   → "売上高" で検索すると "売上高が増加した" を含む文書がヒットする
            "body":         {"type": "text", "analyzer": "kuromoji"},
        }
    },
    "settings": {
        # kuromoji アナライザーの定義
        # kuromoji_tokenizer: 日本語を形態素解析して単語に分割するトークナイザー
        "analysis": {
            "analyzer": {
                "kuromoji": {
                    "type":      "custom",
                    "tokenizer": "kuromoji_tokenizer",
                    "filter": [
                        "kuromoji_baseform",        # 動詞・形容詞を原形に正規化（増加した→増加）
                        "kuromoji_part_of_speech",  # 助詞・助動詞を除去（が・に・を・した）
                        "cjk_width",                # 全角→半角正規化
                        "kuromoji_stemmer",         # 長音正規化（コンピューター→コンピュータ）
                        "lowercase",                # 英字小文字化
                    ]
                }
            }
        }
    },
}


class EdinetIndexer:

    def __init__(self, host: str):
        self.client = OpenSearch(hosts=[host])
        # インデックスが存在しなければ自動作成する
        self._ensure_index()

    def _ensure_index(self):
        """
        インデックスが存在しなければマッピング定義に従って作成する。
        すでに存在する場合は何もしない。

        ※ マッピングを変更したい場合はインデックスを削除してから再作成する:
           curl -X DELETE http://localhost:9200/edinet-reports
        """
        if not self.client.indices.exists(index=INDEX_NAME):
            self.client.indices.create(index=INDEX_NAME, body=MAPPINGS)
            print(f"インデックス作成: {INDEX_NAME}")

    def index_document(self, doc: dict):
        """1件だけインデックスする（主にデバッグ用）"""
        self.client.index(index=INDEX_NAME, id=doc["doc_id"], body=doc)

    def bulk_index(self, docs: list[dict]):
        """
        複数件を一括でインデックスする（本番用）。
        1件ずつ投入するよりHTTPリクエスト数が減って速い。

        【投入するデータの例（docs の1件分）】
        {
            "doc_id":       "S100TS7P",
            "company_name": "ソニーグループ株式会社",
            "edinet_code":  "E01777",
            "form_code":    "030000",
            "form_name":    "有価証券報告書－第107期(2023/04/01－2024/03/31)",
            "period_start": "2023-04-01",
            "period_end":   "2024-03-31",
            "submitted_at": "2024-06-25",
            "body":         "第1【企業の概況】\n売上高 13,020,916百万円..."
        }

        【_id に doc_id を使う理由】
        同じ書類IDで再投入すると上書きになる（重複しない）。
        バッチを再実行しても安全。
        """
        actions = [
            {
                "_index":  INDEX_NAME,
                "_id":     d["doc_id"],  # EDINETの書類IDをOpenSearchのドキュメントIDにする
                "_source": d,
            }
            for d in docs
        ]
        # raise_on_error=False: 一部失敗しても残りを続ける
        success, errors = helpers.bulk(self.client, actions, raise_on_error=False)
        print(f"  bulk: success={success}, errors={len(errors)}")
        return success, errors

    def search(self, query: str, size: int = 10) -> list[dict]:
        """
        全文検索する（動作確認・デバッグ用）。

        【クエリの意味】
        multi_match: 複数フィールドを横断して検索する
        fields: ["company_name^2", "body"]
          → company_name にヒットした場合はスコアを2倍にする（^2）
          → 企業名検索を優先したいため

        【使い方】
        results = indexer.search("売上高")
        for r in results:
            print(r["company_name"], r["submitted_at"])
        """
        body = {
            "query": {
                "multi_match": {
                    "query":  query,
                    "fields": ["company_name^2", "body"],
                }
            },
            "size": size,
        }
        resp = self.client.search(index=INDEX_NAME, body=body)
        return [h["_source"] for h in resp["hits"]["hits"]]
