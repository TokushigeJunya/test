"""EDINET書類取得 → OpenSearchインデックス投入バッチ

【実行順序の全体像】
1. .envからAPIキーなどの設定を読み込む
2. EdinetClient / PdfExtractor / EdinetIndexer を初期化
3. 日付範囲をループして書類メタデータの一覧を取得
4. 各書類のPDFをダウンロードしてテキスト抽出
5. 20件溜まるたびにOpenSearchへbulk投入
"""

import os
from datetime import date
from dotenv import load_dotenv

from edinet.client import EdinetClient
from edinet.extractor import get_extractor
from opensearch.indexer import EdinetIndexer

# ── Step 1: .envファイルから環境変数を読み込む ────────────────────────────────
# .envの内容:
#   EDINET_API_KEY=xxxxxxxxxxxxxxxxxxxx
#   OPENSEARCH_HOST=http://localhost:9200
load_dotenv()

EDINET_API_KEY  = os.environ["EDINET_API_KEY"]
OPENSEARCH_HOST = os.getenv("OPENSEARCH_HOST", "http://localhost:9200")


def build_doc(meta: dict, body: str) -> dict:
    """
    EDINETのAPIレスポンス1件分（meta）と抽出テキスト（body）を
    OpenSearchに投入する形式のdictに変換する。

    【metaに入っているデータの例（EDINET APIのレスポンス）】
    {
        "docID":          "S100TS7P",           # 書類を一意に識別するID
        "edinetCode":     "E01777",             # 企業を一意に識別するコード
        "filerName":      "ソニーグループ株式会社",
        "formCode":       "030000",             # 030000=有価証券報告書
        "docDescription": "有価証券報告書－第107期(2023/04/01－2024/03/31)",
        "periodStart":    "2023-04-01",         # 対象期間の開始
        "periodEnd":      "2024-03-31",         # 対象期間の終了
        "submitDateTime": "2024-06-25 15:36",   # 提出日時
        ...
    }

    【bodyに入っているデータの例】
    "第1【企業の概況】\n1【主要な経営指標等の推移】\n売上高 13,020,916百万円..."
    （pdfminerで抽出したテキスト。先頭30ページ分）
    """
    return {
        "doc_id":       meta.get("docID", ""),
        "company_name": meta.get("filerName", ""),
        "edinet_code":  meta.get("edinetCode", ""),
        "form_code":    meta.get("formCode", ""),
        # docDescription: "有価証券報告書－第107期(2023/04/01－2024/03/31)" のような文字列
        "form_name":    meta.get("docDescription", ""),
        "period_start": meta.get("periodStart"),
        "period_end":   meta.get("periodEnd"),
        # submitDateTimeは "2024-06-25 15:36" 形式なので [:10] で日付部分だけ取り出す
        "submitted_at": meta.get("submitDateTime", "")[:10] if meta.get("submitDateTime") else None,
        "body":         body,
    }


def run(start: date, end: date):
    """
    【処理の流れ】
    ① EdinetClient / PdfExtractor / EdinetIndexer を初期化
    ② 日付範囲の全日をループして書類メタデータを収集（書類一覧フェーズ）
    ③ 収集したメタデータを1件ずつ処理（PDF取得・抽出・インデックスフェーズ）
    ④ 20件溜まるたびにbulk投入、最後に端数を投入
    """

    # ── Step 2: 各クラスを初期化 ─────────────────────────────────────────────
    edinet   = EdinetClient(EDINET_API_KEY)   # EDINET APIクライアント
    extractor = get_extractor("pdf")           # PDFテキスト抽出器
    indexer  = EdinetIndexer(OPENSEARCH_HOST) # OpenSearchへの投入器
    # ※ EdinetIndexer.__init__ の中でインデックスが存在しなければ自動作成される

    # ── Step 3: 書類一覧の取得（日付範囲ループ） ──────────────────────────────
    # EDINET APIは1日単位でしか書類一覧を返さないため、
    # 開始日から終了日まで1日ずつループしてまとめる。
    #
    # 例: --start 2024-04-01 --end 2025-03-31 の場合
    #   2024-04-01 → 6件ヒット（三菱UFJの訂正届出書など）
    #   2024-04-02 → 0件（休日なのでスキップ）
    #   ...
    #   2024-06-25 → 3件ヒット（ソニー・トヨタ・三菱UFJの有価証券報告書）
    #   ...
    # 最終的に136件のメタデータリストが docs_meta に入る
    print(f"=== 書類一覧取得: {start} → {end} ===")
    docs_meta = edinet.fetch_document_list_range(start, end)
    print(f"対象書類: {len(docs_meta)} 件\n")

    # ── Step 4 & 5: PDFダウンロード → テキスト抽出 → インデックス投入 ──────────
    batch = []  # bulk投入用の一時バッファ（20件溜まったら投入）

    for i, meta in enumerate(docs_meta, 1):
        doc_id  = meta.get("docID", "")       # 例: "S100TS7P"
        company = meta.get("filerName", "")   # 例: "ソニーグループ株式会社"
        print(f"[{i}/{len(docs_meta)}] {company} ({doc_id})", flush=True)

        try:
            # Step 4-a: PDFをバイナリで取得
            # 例: GET https://api.edinet-fsa.go.jp/api/v2/documents/S100TS7P?type=2
            # → ソニーの有価証券報告書PDFのバイナリ（数MB）
            pdf_bytes = edinet.download_pdf(doc_id)

            # Step 4-b: PDFバイナリからテキストを抽出
            # 例: b"%PDF-1.4..." → "第1【企業の概況】\n売上高 13,020,916百万円..."
            # ※ 先頭30ページ・10MB以下の制限あり
            body = extractor.extract(pdf_bytes)

            # Step 4-c: metaとbodyを組み合わせてOpenSearch用のdictを作成
            batch.append(build_doc(meta, body))

        except Exception as e:
            # サイズ超過・スキャンエラーなどは1件スキップして続行
            print(f"  スキップ: {e}", flush=True)
            continue

        # Step 5: 20件溜まったらOpenSearchにbulk投入してバッファをクリア
        # （1件ずつ投入するより20件まとめて送る方が速い）
        if len(batch) >= 20:
            indexer.bulk_index(batch)
            batch.clear()

    # ループ終了後、20件未満の端数が残っていれば最後に投入
    if batch:
        indexer.bulk_index(batch)

    print("\n=== 完了 ===")


if __name__ == "__main__":
    import argparse

    # コマンドライン引数で日付範囲を指定する
    # 例: python main.py --start 2024-04-01 --end 2025-03-31
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", required=True, help="開始日 YYYY-MM-DD")
    parser.add_argument("--end",   required=True, help="終了日 YYYY-MM-DD")
    args = parser.parse_args()

    run(
        date.fromisoformat(args.start),
        date.fromisoformat(args.end),
    )
