"""EDINET APIクライアント

【EDINET APIの基本的な仕様】
- 書類一覧取得: GET /api/v2/documents.json?date=YYYY-MM-DD&type=2&Subscription-Key=xxx
  → 指定した1日に提出されたすべての書類のメタデータを返す
  → type=1: メタのみ / type=2: メタ + 提出件数カウント

- 書類ダウンロード: GET /api/v2/documents/{docID}?type=2&Subscription-Key=xxx
  → type=2でPDFバイナリを返す
"""

import time
import requests
from datetime import date, timedelta
from typing import Optional

EDINET_BASE = "https://api.edinet-fsa.go.jp/api/v2"

# 取得対象の書類種別コード
# EDINET APIのレスポンスの "formCode" フィールドで判別する
TARGET_FORM_CODES = {
    "030000",  # 有価証券報告書（年次・最も重要）
    "042000",  # 四半期報告書（Q1/Q3）
    "020000",  # 半期報告書（Q2相当）
}
# ※ 当初 043000（四半期）としていたが実際のAPIレスポンスは 042000 だった

# 取得対象の企業（EDINETコード）
# "edinetCode" フィールドで判別する
TARGET_EDINET_CODES = {
    "E02144",  # トヨタ自動車
    "E01777",  # ソニーグループ
    "E03606",  # 三菱UFJフィナンシャル・グループ
    "E02367",  # 任天堂
    "E01967",  # キーエンス（E01563は井関農機だった。注意）
}


class EdinetClient:
    def __init__(self, api_key: str, edinet_codes: Optional[set] = None):
        self.api_key     = api_key
        # edinet_codesを明示的に渡せば対象企業を上書きできる
        # 渡さなければ上のTARGET_EDINET_CODESがデフォルト
        self.edinet_codes = edinet_codes or TARGET_EDINET_CODES
        self.session     = requests.Session()  # 同一セッションを使い回してTCP接続を再利用

    def _get(self, url: str, params: dict) -> requests.Response:
        """全APIリクエストの共通処理。APIキーを自動付与してGETする。"""
        params["Subscription-Key"] = self.api_key
        resp = self.session.get(url, params=params, timeout=30)
        # 4xx/5xxのときは例外を発生させる（呼び出し元でcatchする）
        resp.raise_for_status()
        return resp

    def fetch_document_list(self, target_date: date) -> list[dict]:
        """
        指定した1日に提出された書類の一覧を取得し、対象企業・書類種別でフィルタして返す。

        【APIリクエスト例】
        GET https://api.edinet-fsa.go.jp/api/v2/documents.json
            ?date=2024-06-25&type=2&Subscription-Key=xxx

        【APIレスポンス例（results の1件分）】
        {
            "docID":          "S100TS7P",
            "edinetCode":     "E01777",              ← 対象企業かどうかの判定に使う
            "filerName":      "ソニーグループ株式会社",
            "formCode":       "030000",              ← 対象書類種別かどうかの判定に使う
            "docDescription": "有価証券報告書－第107期(2023/04/01－2024/03/31)",
            "periodStart":    "2023-04-01",
            "periodEnd":      "2024-03-31",
            "submitDateTime": "2024-06-25 15:36",
            "pdfFlag":        "1",                   ← "1"ならPDFが存在する
            ...
        }

        2024-06-25 の場合、全企業合計で約900件返ってくるが、
        フィルタ後は ソニー・トヨタ・三菱UFJ など数件になる。
        """
        url  = f"{EDINET_BASE}/documents.json"
        resp = self._get(url, {"date": target_date.isoformat(), "type": "2"})
        data = resp.json()
        results = data.get("results", [])

        # formCode と edinetCode の両方が対象に含まれるものだけ残す
        return [
            r for r in results
            if r.get("formCode")   in TARGET_FORM_CODES
            and r.get("edinetCode") in self.edinet_codes
        ]

    def fetch_document_list_range(
        self, start: date, end: date, interval_sec: float = 0.5
    ) -> list[dict]:
        """
        日付範囲の書類一覧をまとめて取得する。
        1日ずつAPIを呼びながら日付をずらしていき、結果を結合して返す。

        【例: 2024-04-01 〜 2025-03-31 を指定した場合】
        2024-04-01: 6件（三菱UFJの訂正届出書など）
        2024-04-02: 0件 → スキップ（土日・祝日・提出なし）
        ...
        2024-06-25: 3件（ソニー・トヨタ・三菱UFJの有報）
        ...
        2025-03-31: 8件
        ─────────────────────────────
        合計: 136件

        interval_sec=0.5 → 1日ぶん取得するたびに0.5秒待つ。
        1年分だと 365 × 0.5秒 ≒ 3分 かかる。
        """
        docs    = []
        current = start

        while current <= end:
            try:
                daily = self.fetch_document_list(current)
                if daily:
                    docs.extend(daily)
                    print(f"  {current.isoformat()}: {len(daily)} 件", flush=True)
            except Exception as e:
                # ネットワークエラーなどは1日分スキップして続行
                print(f"  {current.isoformat()}: スキップ ({e})", flush=True)

            current += timedelta(days=1)
            time.sleep(interval_sec)  # APIへの負荷軽減のため待機

        return docs

    def download_pdf(self, doc_id: str) -> bytes:
        """
        書類IDを指定してPDFバイナリを取得する。

        【APIリクエスト例】
        GET https://api.edinet-fsa.go.jp/api/v2/documents/S100TS7P
            ?type=2&Subscription-Key=xxx

        【レスポンス】
        PDFのバイナリデータ（b"%PDF-1.4 ..."）
        ソニーの有報なら数MB〜十数MBになる。

        type の意味:
          type=1: 提出書類本体（XBRL/HTML）
          type=2: PDF  ← ここで使っている
          type=4: 添付書類
        """
        url  = f"{EDINET_BASE}/documents/{doc_id}"
        resp = self._get(url, {"type": "2"})
        return resp.content
