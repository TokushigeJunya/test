"""PDFテキスト抽出

【処理の流れ】
PDFバイナリ（bytes）
    ↓ pdfminer が解析
生テキスト（改行・空白が多い）
    ↓ _clean() で整形
クリーンなテキスト（str）

【XBRLへの拡張方法】
XbrlExtractor(DocumentExtractor) を追加して
get_extractor("xbrl") と呼ぶだけで差し替えられる。
main.py 側は何も変えなくていい。
"""

import io
from abc import ABC, abstractmethod
from pdfminer.high_level import extract_text


class DocumentExtractor(ABC):
    """抽出器の共通インターフェース。PDFもXBRLもこれを実装する。"""

    @abstractmethod
    def extract(self, raw: bytes) -> str:
        """バイナリから本文テキストを返す"""
        ...


# サイズ・ページ制限（速度対策）
MAX_PAGES = 30                      # 先頭30ページまで抽出
MAX_BYTES = 10 * 1024 * 1024        # 10MB超はスキップ（有報PDFは大きいものが多い）


class PdfExtractor(DocumentExtractor):

    def extract(self, raw: bytes) -> str:
        """
        PDFバイナリからテキストを抽出して返す。

        【入力例】
        raw = b"%PDF-1.4 1 0 obj\n..." （ソニーの有報PDF、約8MB）

        【処理】
        1. サイズチェック: 10MB超なら RuntimeError を raise してスキップ
        2. pdfminer で先頭30ページのテキストを抽出
        3. _clean() で空行・余分なスペースを除去

        【出力例】
        "第1【企業の概況】
        1【主要な経営指標等の推移】
        売上高 13,020,916百万円
        営業利益 1,208,765百万円
        ..."

        【なぜ先頭30ページか】
        有報の構成:
          1〜5ページ:  表紙・目次
          6〜30ページ: 企業の概況・事業内容・リスク・財務ハイライト  ← 検索で重要な情報
          30ページ〜:  詳細な財務諸表・注記（数百ページに及ぶ）
        検索用途では前半で十分。
        """
        # サイズチェック（10MB超はスキップ）
        if len(raw) > MAX_BYTES:
            raise RuntimeError(f"PDFサイズ超過: {len(raw) // 1024 // 1024}MB")

        try:
            # io.BytesIO でバイナリをファイルオブジェクトに変換してpdfminerに渡す
            # maxpages=30 で先頭30ページまでに制限
            text = extract_text(io.BytesIO(raw), maxpages=MAX_PAGES)
            return self._clean(text)
        except Exception as e:
            raise RuntimeError(f"PDF抽出失敗: {e}") from e

    def _clean(self, text: str) -> str:
        """
        pdfminerの出力テキストを整形する。

        【整形前の例】
        "  第1【企業の概況】  \n\n\n  1【主要な経営指標等の推移】  \n\n"

        【整形後の例】
        "第1【企業の概況】
        1【主要な経営指標等の推移】"

        やっていること:
        1. 各行の前後の空白を除去（strip）
        2. 空行を除去
        3. 改行で結合
        """
        lines = [line.strip() for line in text.splitlines()]
        lines = [line for line in lines if line]  # 空行を除去
        return "\n".join(lines)


# ── XBRL対応を追加するときはここに実装する ────────────────────────────────────
# class XbrlExtractor(DocumentExtractor):
#     def extract(self, raw: bytes) -> str:
#         # XBRLのパース処理
#         ...


def get_extractor(format: str = "pdf") -> DocumentExtractor:
    """
    フォーマット名を渡すと対応する抽出器を返す。

    使い方:
        extractor = get_extractor("pdf")
        text = extractor.extract(pdf_bytes)

    将来XBRLに対応したら:
        extractor = get_extractor("xbrl")  # これだけでXBRL抽出器に切り替わる
    """
    if format == "pdf":
        return PdfExtractor()
    raise ValueError(f"未対応のフォーマット: {format}")
